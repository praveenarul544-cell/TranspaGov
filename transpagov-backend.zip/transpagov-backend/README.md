# TranspaGov Backend (hackathon)

Express + TypeScript API with an explainable AI-style risk engine, in-memory seed data (Tamil Nadu projects).

## Run
```bash
npm install
npm run dev        # http://localhost:4000
```

## Endpoints (all under /api)
| Method | Path | Purpose |
|---|---|---|
| GET | /meta | project types, districts, risk levels (filters) |
| GET | /contractors | contractor list |
| GET | /projects?region=&type=&contractor=&level=&onlyHigh=true&sort=risk\|delay\|budget\|name&q= | scored + filtered projects |
| GET | /projects/:id | one project with factors, reasons, alerts, contractor |
| POST | /projects | create project |
| PATCH | /projects/:id/spend | new bill released -> rescore, auto-alert |
| POST | /projects/:id/verification | AI image verification result -> rescore, auto-alert |
| GET | /alerts?status=active&projectId= | alerts |
| POST | /alerts | citizen/field report |
| PATCH | /alerts/:id | resolve / acknowledge |
| GET | /dashboard/summary | KPIs, risk donut, budget bars, monthly alerts, top 5 |
| GET | /reports/executive-summary | generated summary text |

## Risk score (0-100)
Budget overrun 25% + Delay 25% + Fraud 20% + Image mismatch 15% + Anomalies 15%.
0-30 Low · 31-60 Medium · 61-80 High · 81-100 Critical. Every project returns `factors[]` and `reasons[]` for explainability.

## Demo trick
```bash
curl -X POST localhost:4000/api/projects/p8/verification -H "Content-Type: application/json" -d '{"visualProgress":30,"confidence":0.9}'
```
Watch p8 jump up the risk list and a new alert appear.

## Next steps
Swap `store.ts` for Postgres/SQLite (Prisma), add auth, plug a real vision model into the verification endpoint.
