import { contractors, projects as seed } from "./data";
import { scoreProject } from "./riskEngine";
import type { Alert, Contractor, Project, ScoredProject } from "./types";

export const db = {
  contractors: [...contractors] as Contractor[],
  projects: seed.map((p) => ({ ...p })) as Project[],
  alerts: [] as Alert[],
};

export const getContractor = (id: string) => db.contractors.find((c) => c.id === id);

/** Always sorted by risk score (highest first) so "top 5" on the dashboard works. */
export function scoredProjects(): ScoredProject[] {
  return db.projects
    .map((p) => scoreProject(p, getContractor(p.contractorId)))
    .sort((a, b) => b.score - a.score);
}

export const scoredProject = (id: string) => {
  const p = db.projects.find((x) => x.id === id);
  return p ? scoreProject(p, getContractor(p.contractorId)) : undefined;
};

let alertSeq = 1;
export const nextAlertId = () => `a-${Date.now().toString(36)}-${alertSeq++}`;

export function addAlert(a: Omit<Alert, "id" | "createdAt" | "resolved" | "acknowledged"> & Partial<Alert>): Alert {
  const alert: Alert = {
    id: nextAlertId(),
    createdAt: new Date().toISOString(),
    resolved: false,
    acknowledged: false,
    ...a,
  };
  db.alerts.unshift(alert);
  return alert;
}

// ---- seed alerts: derived from each project's risky factors, spread across the last 6 months ----
(function seedAlerts() {
  const now = new Date();
  scoredProjects().forEach((p, i) => {
    p.factors
      .filter((f) => f.score >= 50)
      .forEach((f, j) => {
        const d = new Date(now.getFullYear(), now.getMonth() - ((i + j) % 6), 3 + ((i * 5 + j * 7) % 24));
        if (d > now) d.setMonth(d.getMonth() - 1);
        db.alerts.push({
          id: `a-${p.id}-${f.key}`,
          projectId: p.id,
          severity: p.level === "high" || p.level === "critical" ? "high" : "medium",
          title: f.label,
          message: f.explanation,
          source: "ai",
          createdAt: d.toISOString(),
          resolved: false,
          acknowledged: false,
        });
      });
  });
  db.alerts.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
})();
