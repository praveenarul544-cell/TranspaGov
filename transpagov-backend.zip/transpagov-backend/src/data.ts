import type { Contractor, Project } from "./types";

export const PROJECT_TYPES = ["Road", "Bridge", "Water Supply", "Drainage", "School Building", "Hospital"];

const now = Date.now();
const iso = (offsetDays: number) => new Date(now + offsetDays * 86_400_000).toISOString().slice(0, 10);

export const contractors: Contractor[] = [
  { id: "c1", name: "Sri Venkateswara Constructions", pastDelayedProjects: 3, blacklistFlags: 1, rating: 2.1 },
  { id: "c2", name: "Kaveri Infra Pvt Ltd", pastDelayedProjects: 1, blacklistFlags: 0, rating: 3.8 },
  { id: "c3", name: "Pandian Builders", pastDelayedProjects: 2, blacklistFlags: 0, rating: 3.0 },
  { id: "c4", name: "Tamirabarani Engineering", pastDelayedProjects: 0, blacklistFlags: 0, rating: 4.6 },
  { id: "c5", name: "Coastal Works & Co", pastDelayedProjects: 4, blacklistFlags: 1, rating: 1.9 },
];

export const projects: Project[] = [
  { id: "p1", name: "Chennai Outer Ring Road Phase 2", district: "Chennai", type: "Road", contractorId: "c1", budgetCr: 480, spentCr: 410, reportedProgress: 85, visualProgress: 58, verificationConfidence: 0.82, startDate: iso(-630), plannedEnd: iso(-150), anomalyCount: 5, fraudSignals: 45, lat: 13.0, lng: 80.15 },
  { id: "p2", name: "Coimbatore Flyover at Avinashi Road", district: "Coimbatore", type: "Bridge", contractorId: "c5", budgetCr: 220, spentCr: 170, reportedProgress: 75, visualProgress: 52, verificationConfidence: 0.78, startDate: iso(-500), plannedEnd: iso(-60), anomalyCount: 4, fraudSignals: 40, lat: 11.02, lng: 76.97 },
  { id: "p3", name: "Madurai Vaigai Riverfront Drainage", district: "Madurai", type: "Drainage", contractorId: "c3", budgetCr: 95, spentCr: 70, reportedProgress: 70, visualProgress: 55, verificationConfidence: 0.85, startDate: iso(-400), plannedEnd: iso(-30), anomalyCount: 2, fraudSignals: 30, lat: 9.92, lng: 78.12 },
  { id: "p4", name: "Trichy Combined Water Supply Scheme", district: "Tiruchirappalli", type: "Water Supply", contractorId: "c2", budgetCr: 310, spentCr: 190, reportedProgress: 64, visualProgress: 58, verificationConfidence: 0.9, startDate: iso(-420), plannedEnd: iso(120), anomalyCount: 1, fraudSignals: 15, lat: 10.79, lng: 78.69 },
  { id: "p5", name: "Salem Government Hospital Block B", district: "Salem", type: "Hospital", contractorId: "c3", budgetCr: 140, spentCr: 96, reportedProgress: 72, visualProgress: 60, verificationConfidence: 0.88, startDate: iso(-380), plannedEnd: iso(40), anomalyCount: 2, fraudSignals: 20, lat: 11.66, lng: 78.14 },
  { id: "p6", name: "Tirunelveli Tamirabarani Bridge", district: "Tirunelveli", type: "Bridge", contractorId: "c4", budgetCr: 180, spentCr: 120, reportedProgress: 68, visualProgress: 66, verificationConfidence: 0.93, startDate: iso(-360), plannedEnd: iso(90), anomalyCount: 0, fraudSignals: 5, lat: 8.73, lng: 77.7 },
  { id: "p7", name: "Vellore Smart School Complex", district: "Vellore", type: "School Building", contractorId: "c2", budgetCr: 60, spentCr: 34, reportedProgress: 58, visualProgress: 56, verificationConfidence: 0.92, startDate: iso(-250), plannedEnd: iso(110), anomalyCount: 0, fraudSignals: 8, lat: 12.92, lng: 79.13 },
  { id: "p8", name: "Erode NH-544 Widening", district: "Erode", type: "Road", contractorId: "c4", budgetCr: 350, spentCr: 205, reportedProgress: 60, visualProgress: 59, verificationConfidence: 0.95, startDate: iso(-300), plannedEnd: iso(150), anomalyCount: 0, fraudSignals: 3, lat: 11.34, lng: 77.72 },
  { id: "p9", name: "Chennai Adyar Storm Water Drain", district: "Chennai", type: "Drainage", contractorId: "c2", budgetCr: 125, spentCr: 80, reportedProgress: 66, visualProgress: 60, verificationConfidence: 0.87, startDate: iso(-330), plannedEnd: iso(30), anomalyCount: 1, fraudSignals: 12, lat: 13.01, lng: 80.25 },
  { id: "p10", name: "Madurai Village Water Tanks", district: "Madurai", type: "Water Supply", contractorId: "c4", budgetCr: 45, spentCr: 20, reportedProgress: 48, visualProgress: 47, verificationConfidence: 0.94, startDate: iso(-200), plannedEnd: iso(160), anomalyCount: 0, fraudSignals: 2, lat: 9.97, lng: 78.2 },
];
