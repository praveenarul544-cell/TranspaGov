import { Router } from "express";
import { z } from "zod";
import { contractors, PROJECT_TYPES } from "./data";
import { addAlert, db, getContractor, scoredProject, scoredProjects } from "./store";
import { levelFor } from "./riskEngine";
import type { Project } from "./types";

export const router = Router();

const wrap =
  (fn: (req: any, res: any) => any) =>
  (req: any, res: any, next: any) =>
    Promise.resolve(fn(req, res)).catch(next);

// ---------- meta ----------
router.get("/meta", (_req, res) => {
  const districts = Array.from(new Set(db.projects.map((p) => p.district))).sort();
  res.json({ projectTypes: PROJECT_TYPES, districts, riskLevels: ["low", "medium", "high", "critical"] });
});

router.get("/contractors", (_req, res) => res.json(db.contractors));

// ---------- projects ----------
const listQuery = z.object({
  region: z.string().optional(),
  type: z.string().optional(),
  contractor: z.string().optional(),
  level: z.enum(["low", "medium", "high", "critical"]).optional(),
  onlyHigh: z.enum(["true", "false"]).optional(),
  q: z.string().optional(),
  sort: z.enum(["risk", "delay", "budget", "name"]).default("risk"),
});

router.get("/projects", (req, res) => {
  const q = listQuery.parse(req.query);
  let ps = scoredProjects().filter(
    (p) =>
      (!q.region || p.district === q.region) &&
      (!q.type || p.type === q.type) &&
      (!q.contractor || p.contractorId === q.contractor) &&
      (!q.level || p.level === q.level) &&
      (q.onlyHigh !== "true" || p.level === "high" || p.level === "critical") &&
      (!q.q || p.name.toLowerCase().includes(q.q.toLowerCase())),
  );
  const sorters = {
    risk: (a: any, b: any) => b.score - a.score,
    delay: (a: any, b: any) => b.delayDays - a.delayDays,
    budget: (a: any, b: any) => b.budgetPct - a.budgetPct,
    name: (a: any, b: any) => a.name.localeCompare(b.name),
  };
  ps = [...ps].sort(sorters[q.sort]);
  res.json(ps);
});

router.get("/projects/:id", (req, res) => {
  const p = scoredProject(req.params.id);
  if (!p) return res.status(404).json({ error: "Project not found" });
  res.json({ ...p, alerts: db.alerts.filter((a) => a.projectId === p.id), contractor: getContractor(p.contractorId) });
});

const createProject = z.object({
  name: z.string().min(3),
  district: z.string().min(2),
  type: z.string().min(2),
  contractorId: z.string(),
  budgetCr: z.number().positive(),
  spentCr: z.number().min(0).default(0),
  reportedProgress: z.number().min(0).max(100).default(0),
  visualProgress: z.number().min(0).max(100).default(0),
  verificationConfidence: z.number().min(0).max(1).default(0.8),
  startDate: z.string(),
  plannedEnd: z.string(),
  anomalyCount: z.number().int().min(0).default(0),
  fraudSignals: z.number().min(0).max(100).default(0),
  lat: z.number().optional(),
  lng: z.number().optional(),
});

router.post("/projects", (req, res) => {
  const body = createProject.parse(req.body);
  if (!getContractor(body.contractorId)) return res.status(400).json({ error: "Unknown contractorId" });
  const project: Project = { id: `p${Date.now().toString(36)}`, ...body };
  db.projects.push(project);
  res.status(201).json(scoredProject(project.id));
});

/** Update financial numbers (e.g. new bill released). */
const spendBody = z.object({ spentCr: z.number().min(0), reportedProgress: z.number().min(0).max(100).optional() });
router.patch("/projects/:id/spend", (req, res) => {
  const p = db.projects.find((x) => x.id === req.params.id);
  if (!p) return res.status(404).json({ error: "Project not found" });
  const b = spendBody.parse(req.body);
  const before = scoredProject(p.id)!;
  p.spentCr = b.spentCr;
  if (b.reportedProgress !== undefined) p.reportedProgress = b.reportedProgress;
  const after = scoredProject(p.id)!;
  if (after.budgetPct - after.visualProgress >= 20) {
    addAlert({ projectId: p.id, severity: "high", title: "Payment ahead of work", message: after.factors[0].explanation, source: "ai" });
  }
  res.json({ before: before.score, after });
});

/** Called by the AI image-verification pipeline (or manually for demo). */
const verifyBody = z.object({
  visualProgress: z.number().min(0).max(100),
  confidence: z.number().min(0).max(1).default(0.85),
  imageUrl: z.string().url().optional(),
});
router.post("/projects/:id/verification", (req, res) => {
  const p = db.projects.find((x) => x.id === req.params.id);
  if (!p) return res.status(404).json({ error: "Project not found" });
  const b = verifyBody.parse(req.body);
  const before = scoredProject(p.id)!;
  p.visualProgress = b.visualProgress;
  p.verificationConfidence = b.confidence;
  const gap = p.reportedProgress - p.visualProgress;
  if (gap >= 20) {
    addAlert({
      projectId: p.id,
      severity: gap >= 30 ? "high" : "medium",
      title: "Image verification mismatch",
      message: `Contractor reports ${p.reportedProgress}% but new site images show ${p.visualProgress}%.`,
      source: "ai",
    });
  }
  res.json({ scoreBefore: before.score, project: scoredProject(p.id) });
});

// ---------- alerts ----------
router.get("/alerts", (req, res) => {
  const { projectId, status } = req.query as Record<string, string | undefined>;
  let list = db.alerts;
  if (projectId) list = list.filter((a) => a.projectId === projectId);
  if (status === "active") list = list.filter((a) => !a.resolved);
  if (status === "resolved") list = list.filter((a) => a.resolved);
  res.json(list);
});

const alertCreate = z.object({
  projectId: z.string(),
  title: z.string().min(3),
  message: z.string().min(3),
  severity: z.enum(["high", "medium", "low"]).default("medium"),
});
/** Citizen / field-officer report. */
router.post("/alerts", (req, res) => {
  const b = alertCreate.parse(req.body);
  if (!db.projects.some((p) => p.id === b.projectId)) return res.status(400).json({ error: "Unknown projectId" });
  res.status(201).json(addAlert({ ...b, source: "field" }));
});

const alertPatch = z.object({ resolved: z.boolean().optional(), acknowledged: z.boolean().optional(), note: z.string().optional() });
router.patch("/alerts/:id", (req, res) => {
  const a = db.alerts.find((x) => x.id === req.params.id);
  if (!a) return res.status(404).json({ error: "Alert not found" });
  Object.assign(a, alertPatch.parse(req.body));
  res.json(a);
});

// ---------- dashboard ----------
router.get("/dashboard/summary", (_req, res) => {
  const all = scoredProjects();
  const totalBudgetCr = all.reduce((s, p) => s + p.budgetCr, 0);
  const totalSpentCr = all.reduce((s, p) => s + p.spentCr, 0);

  const riskDistribution = (["low", "medium", "high", "critical"] as const).map((level) => ({
    level,
    count: all.filter((p) => p.level === level).length,
  }));

  const budgetByType = PROJECT_TYPES.map((type) => {
    const ps = all.filter((p) => p.type === type);
    return {
      type,
      budgetCr: Math.round(ps.reduce((s, p) => s + p.budgetCr, 0)),
      spentCr: Math.round(ps.reduce((s, p) => s + p.spentCr, 0)),
      workValueCr: Math.round(ps.reduce((s, p) => s + p.workValueCr, 0)),
    };
  }).filter((r) => r.budgetCr > 0);

  const now = new Date();
  const monthlyAlerts = Array.from({ length: 6 }, (_, i) => {
    const d = new Date(now.getFullYear(), now.getMonth() - (5 - i), 1);
    const inMonth = db.alerts.filter((a) => {
      const c = new Date(a.createdAt);
      return c.getFullYear() === d.getFullYear() && c.getMonth() === d.getMonth();
    });
    return {
      month: d.toLocaleString("en-IN", { month: "short" }),
      high: inMonth.filter((a) => a.severity === "high").length,
      medium: inMonth.filter((a) => a.severity === "medium").length,
    };
  });

  res.json({
    kpis: {
      totalProjects: all.length,
      highRisk: all.filter((p) => p.level === "high" || p.level === "critical").length,
      totalBudgetCr: Math.round(totalBudgetCr),
      totalSpentCr: Math.round(totalSpentCr),
      budgetUsedPct: Math.round((totalSpentCr / totalBudgetCr) * 100),
      activeAlerts: db.alerts.filter((a) => !a.resolved).length,
    },
    riskDistribution,
    budgetByType,
    monthlyAlerts,
    topAttention: all.slice(0, 5),
  });
});

// ---------- reports ----------
router.get("/reports/executive-summary", (_req, res) => {
  const all = scoredProjects();
  const critical = all.filter((p) => p.level === "critical");
  const high = all.filter((p) => p.level === "high");
  const exposure = all
    .filter((p) => p.level === "high" || p.level === "critical")
    .reduce((s, p) => s + Math.max(0, p.spentCr - p.workValueCr), 0);
  res.json({
    generatedAt: new Date().toISOString(),
    headline: `${critical.length + high.length} of ${all.length} projects need action; ~₹${Math.round(exposure)} Cr of spend is ahead of verified work.`,
    exposureCr: Math.round(exposure),
    bullets: all.slice(0, 5).map((p) => `${p.name} (${p.district}) — score ${p.score}, ${p.level.toUpperCase()}: ${p.reasons[0] ?? "no major issues"}`),
    recommendedActions: all.slice(0, 5).map((p) => ({ projectId: p.id, project: p.name, action: p.action })),
    levelOfScore: levelFor(Math.round(all.reduce((s, p) => s + p.score, 0) / all.length)),
  });
});
