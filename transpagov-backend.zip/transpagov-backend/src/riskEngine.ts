import type { Contractor, Project, RiskFactor, RiskLevel, ScoredProject } from "./types";

const DAY = 86_400_000;
const clamp = (n: number, lo = 0, hi = 100) => Math.min(hi, Math.max(lo, n));
const r1 = (n: number) => Math.round(n * 10) / 10;

export const WEIGHTS = { budget: 0.25, delay: 0.25, fraud: 0.2, image: 0.15, anomaly: 0.15 } as const;

/** 0-30 Low, 31-60 Medium, 61-80 High, 81-100 Critical (matches the dashboard tooltip). */
export function levelFor(score: number): RiskLevel {
  if (score <= 30) return "low";
  if (score <= 60) return "medium";
  if (score <= 80) return "high";
  return "critical";
}

export const ACTIONS: Record<RiskLevel, string> = {
  low: "Routine monitoring",
  medium: "Review this month",
  high: "Send field inspection",
  critical: "Escalate immediately",
};

export function computeDelayDays(p: Project, now = new Date()): number {
  if (p.visualProgress >= 100) return 0;
  const start = +new Date(p.startDate);
  const end = +new Date(p.plannedEnd);
  const t = +now;
  if (t > end) return Math.round((t - end) / DAY);
  const total = end - start;
  const expected = clamp(((t - start) / total) * 100);
  return Math.max(0, Math.round(((expected - p.visualProgress) / 100) * (total / DAY)));
}

export function scoreProject(p: Project, c: Contractor | undefined, now = new Date()): ScoredProject {
  const budgetPct = Math.round((p.spentCr / p.budgetCr) * 100);
  const workValueCr = r1((p.budgetCr * p.visualProgress) / 100);
  const delayDays = computeDelayDays(p, now);

  const spendGap = budgetPct - p.visualProgress; // money ahead of verified work
  const imageGap = p.reportedProgress - p.visualProgress; // claimed vs AI-verified work
  const contractorRisk = c ? c.blacklistFlags * 25 + c.pastDelayedProjects * 8 : 0;

  const raw: Omit<RiskFactor, "contribution">[] = [
    {
      key: "budget",
      label: "Budget overrun",
      weight: WEIGHTS.budget,
      score: clamp(spendGap * 3),
      explanation: `${budgetPct}% of budget spent vs ${p.visualProgress}% verified work (₹${r1(p.spentCr - workValueCr)} Cr ahead of work).`,
    },
    {
      key: "delay",
      label: "Schedule delay",
      weight: WEIGHTS.delay,
      score: clamp((delayDays / 180) * 100),
      explanation: delayDays > 0 ? `${delayDays} days behind schedule.` : "On schedule.",
    },
    {
      key: "fraud",
      label: "Fraud signals",
      weight: WEIGHTS.fraud,
      score: clamp(p.fraudSignals + contractorRisk),
      explanation: `Document checks flagged ${p.fraudSignals}/100; contractor has ${c?.pastDelayedProjects ?? 0} past delayed projects and ${c?.blacklistFlags ?? 0} blacklist flags.`,
    },
    {
      key: "image",
      label: "Image verification",
      weight: WEIGHTS.image,
      score: clamp(imageGap * 4 + (1 - p.verificationConfidence) * 20),
      explanation: `Contractor reports ${p.reportedProgress}% but site images show ${p.visualProgress}% (confidence ${Math.round(p.verificationConfidence * 100)}%).`,
    },
    {
      key: "anomaly",
      label: "Anomalies",
      weight: WEIGHTS.anomaly,
      score: clamp(p.anomalyCount * 20),
      explanation: `${p.anomalyCount} billing/timeline anomalies detected.`,
    },
  ];

  const factors: RiskFactor[] = raw.map((f) => ({
    ...f,
    score: Math.round(f.score),
    contribution: r1(f.score * f.weight),
  }));
  const score = Math.round(clamp(factors.reduce((s, f) => s + f.contribution, 0)));
  const level = levelFor(score);
  const reasons = [...factors]
    .filter((f) => f.score >= 40)
    .sort((a, b) => b.contribution - a.contribution)
    .slice(0, 3)
    .map((f) => f.explanation);

  return {
    ...p,
    contractorName: c?.name ?? "Unknown",
    budgetPct,
    workValueCr,
    delayDays,
    score,
    level,
    action: ACTIONS[level],
    factors,
    reasons,
  };
}
