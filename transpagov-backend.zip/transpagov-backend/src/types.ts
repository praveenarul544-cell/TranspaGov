export type RiskLevel = "low" | "medium" | "high" | "critical";

export interface Contractor {
  id: string;
  name: string;
  pastDelayedProjects: number;
  blacklistFlags: number;
  rating: number; // 1-5
}

export interface Project {
  id: string;
  name: string;
  district: string;
  type: string;
  contractorId: string;
  budgetCr: number;
  spentCr: number;
  reportedProgress: number; // % claimed by contractor
  visualProgress: number; // % verified by AI image analysis
  verificationConfidence: number; // 0-1
  startDate: string; // ISO
  plannedEnd: string; // ISO
  anomalyCount: number; // AI-detected billing/timeline anomalies
  fraudSignals: number; // 0-100 from document / duplicate-invoice checks
  lat?: number;
  lng?: number;
}

export interface RiskFactor {
  key: "budget" | "delay" | "fraud" | "image" | "anomaly";
  label: string;
  score: number; // 0-100
  weight: number; // 0-1
  contribution: number; // points added to final score
  explanation: string;
}

export interface ScoredProject extends Project {
  contractorName: string;
  budgetPct: number; // % of budget spent
  workValueCr: number; // budget x verified progress
  delayDays: number;
  score: number; // 0-100
  level: RiskLevel;
  action: string;
  factors: RiskFactor[];
  reasons: string[]; // top human-readable reasons
}

export interface Alert {
  id: string;
  projectId: string;
  severity: "high" | "medium" | "low";
  title: string;
  message: string;
  source: "ai" | "field";
  createdAt: string;
  resolved: boolean;
  acknowledged: boolean;
  note?: string;
}
