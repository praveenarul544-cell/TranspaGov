// Copy to src/lib/api.ts in the frontend. Set VITE_API_URL=http://localhost:4000/api in .env
import { useCallback, useEffect, useState } from "react";

const BASE = (import.meta as any).env?.VITE_API_URL ?? "http://localhost:4000/api";

export async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...init,
  });
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error ?? res.statusText);
  return res.json();
}

export function useApi<T>(path: string, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState(true);
  const load = useCallback(() => {
    setLoading(true);
    api<T>(path).then(setData).catch(setError).finally(() => setLoading(false));
  }, [path]);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(load, [load, ...deps]);
  return { data, error, loading, reload: load };
}

// Examples:
//   const { data: projects } = useApi<ScoredProject[]>("/projects");          // replaces useScoredProjects()
//   const { data: summary }  = useApi<any>("/dashboard/summary");              // KPIs + chart data
//   const { data: meta }     = useApi<{ projectTypes: string[]; districts: string[] }>("/meta");
//   api("/alerts/" + id, { method: "PATCH", body: JSON.stringify({ resolved: true }) });
